package com.floridapoly.alex.cryptocurrency.data;

import org.json.JSONObject;

/**
 * Created by Adam Seevers on 9/29/2017.
 * Cryptocurrency project - Mobile Dev
 */

public interface JSONHandler {
    void populate(JSONObject data);
}
